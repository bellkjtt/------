TBB 문제 있을 시, 다음과 같이 실행

conda install pytorch -c pytorch
pip install django
pip install opencv-python
pip install numpy
pip install ultralytics

pip install tensorflow